# April Wang Portfolio

Minimal Next.js portfolio inspired by MachineFusion.
